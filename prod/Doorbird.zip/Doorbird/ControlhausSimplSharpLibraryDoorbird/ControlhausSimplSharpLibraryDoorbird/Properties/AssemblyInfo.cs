﻿using System.Reflection;

[assembly: AssemblyTitle("ControlhausSimplSharpLibraryDoorbird")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ControlhausSimplSharpLibraryDoorbird")]
[assembly: AssemblyCopyright("Copyright ©  2016")]
[assembly: AssemblyVersion("1.0.0.*")]

