namespace ControlhausSIMPLSharpLibraryDoorbird;
        // class declarations
         class SimplSharpDoorbirdUrls;
         class SimplSharpDoorbirdCommunications;
     class SimplSharpDoorbirdUrls 
    {
        // class delegates

        // class events

        // class functions
        STRING_FUNCTION createLiveVideoUrl ( STRING userName , STRING password , STRING doorbirdHost );
        STRING_FUNCTION createLiveImageUrl ( STRING userName , STRING password , STRING doorbirdHost );
        STRING_FUNCTION createHistoryImageUrl ( STRING userName , STRING password , STRING doorbirdHost , SIGNED_LONG_INTEGER imageIndex );
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
    };

     class SimplSharpDoorbirdCommunications 
    {
        // class delegates
        delegate FUNCTION SimplPlusDataHandler ( SIMPLSHARPSTRING key , SIMPLSHARPSTRING value );

        // class events

        // class functions
        FUNCTION initializeClient ( SIGNED_LONG_INTEGER debug , STRING userName , STRING password , STRING doorbirdHost , SIGNED_INTEGER processorEthernetAdapterId , SIGNED_LONG_INTEGER serverNotificationPort , SIGNED_LONG_INTEGER doorBellNotificationRelaxationTime , SIGNED_LONG_INTEGER motionSensorNotificationRelaxationTime , SIGNED_LONG_INTEGER doorOpenNotificationRelaxationTime );
        FUNCTION setDoorBellNotificationRelaxationTime ( SIGNED_LONG_INTEGER time );
        FUNCTION setMotionSensorNotificationRelaxationTime ( SIGNED_LONG_INTEGER time );
        FUNCTION setDoorOpenNotificationRelaxationTime ( SIGNED_LONG_INTEGER time );
        STRING_FUNCTION getProcessorIP ( SIGNED_INTEGER processorEthernetAdapterId );
        FUNCTION request ( STRING request__1__ );
        FUNCTION get ( STRING getRequest );
        FUNCTION initializeServer ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        INTEGER __class_id__;

        // class properties
        DelegateProperty SimplPlusDataHandler onSimplPlusDataHandler;
    };

